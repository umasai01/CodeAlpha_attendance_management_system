/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atd_mn_sys;

/**
 *
 * @author VINIT
 */
public class StudentInfo {
    String namee,pidd;

    public StudentInfo(String namee, String pidd) {
        this.namee = namee;
        this.pidd = pidd;
    }

    public String getNamee() {
        return namee;
    }

    public void setNamee(String namee) {
        this.namee = namee;
    }

    public String getPidd() {
        return pidd;
    }

    public void setPidd(String pidd) {
        this.pidd = pidd;
    }
    
}
